//
//  StyleDictionaryAppDelegate.h
//  StyleDictionary
//
//  Created by Danny Banks on 02/09/2017.
//  Copyright (c) 2017 Danny Banks. All rights reserved.
//

@import UIKit;
#import <StyleDictionary/StyleDictionary.h>

@interface StyleDictionaryAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
