//
//  main.m
//  StyleDictionaryExample
//
//  Created by Danny Banks on 01/20/2017.
//  Copyright (c) 2017 Danny Banks. All rights reserved.
//

@import UIKit;
#import "StyleDictionaryAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([StyleDictionaryAppDelegate class]));
    }
}
