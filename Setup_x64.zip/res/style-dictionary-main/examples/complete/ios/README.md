# StyleDictionary

[![CI Status](http://img.shields.io/travis/Danny Banks/StyleDictionary.svg?style=flat)](https://travis-ci.org/Danny Banks/StyleDictionary)
[![Version](https://img.shields.io/cocoapods/v/StyleDictionary.svg?style=flat)](http://cocoapods.org/pods/StyleDictionary)
[![License](https://img.shields.io/cocoapods/l/StyleDictionary.svg?style=flat)](http://cocoapods.org/pods/StyleDictionary)
[![Platform](https://img.shields.io/cocoapods/p/StyleDictionary.svg?style=flat)](http://cocoapods.org/pods/StyleDictionary)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

StyleDictionary is available through [CocoaPods](http://cocoapods.org). To install
it, you can add the following line to your Podfile:

```ruby
pod "StyleDictionary"
```

## Author

Danny Banks, djb@amazon.com

## License

StyleDictionary is available under the MIT license. See the LICENSE file for more info.
