/**
 * Do not edit directly
 * Generated on Fri, 18 Dec 2020 00:08:57 GMT
 */

export const colorBrand01 = "#eeeeff";
export const colorBrand02 = "#ddaa33";
export const sizeFontSm = {"original":"16px","number":16,"decimal":0.16,"scale":256};
export const sizeFontMd = {"original":"2rem","number":2,"decimal":0.02,"scale":32};