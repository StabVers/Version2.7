module.exports = {
  color: require('./color'),
  size: require('./size')
}