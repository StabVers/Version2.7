module.exports = {
  padding: require('./padding'),
  font: require('./font'),
  border: require('./border')
}