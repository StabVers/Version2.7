module.exports = {
  base: { value: "{color.core.grey.20.value}" }
}