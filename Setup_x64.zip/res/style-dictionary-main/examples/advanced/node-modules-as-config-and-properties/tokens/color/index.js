// This is kinda cool, don't have to do that
// weird JSON structure nesting in every file.
module.exports = {
  core: require('./core'),
  brand: require('./brand'),
  font: require('./font'),
  background: require('./background'),
  border: require('./border')
}