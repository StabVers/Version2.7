module.exports = {
  base: { value: "#ffffff" },
  alt: { value: "{color.core.grey.20.value}" },
  link: { value: "{color.brand.primary.base.value}" }
};