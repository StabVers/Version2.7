module.exports = {
  primary: require('./primary'),
  secondary: require('./secondary')
}