# style_dictionary

A Flutter package project to show the usage of styled-dictionary's flutter support.